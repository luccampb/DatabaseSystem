<!-- This is a template for the README.md that you should submit. For instructions on how to get started, see INSTRUCTIONS.md -->
# Design Choices

<!-- Write suggestions for improving the design of the tables here -->

# Task Implementations

<!-- For each of the tasks below, please write around 100-200 words explaining how your solution works (describing the behaviour of your SQL statements/queries) -->

## Task 1

## Task 2

## Task 3

## Task 4

## Task 5

## Task 6

## Task 7

## Task 8